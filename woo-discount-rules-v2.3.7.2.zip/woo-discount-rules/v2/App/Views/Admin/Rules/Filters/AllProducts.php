<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
?>
<div class="all_products">
    <!--<div class="all_products_group">
       <div class="wdr-product_filter_method">
            <select name="filters[{i}][method]" style="cursor: none;" disabled>
                <option value="in_list" selected><?php /*_e('In List', 'woo-discount-rules'); */ ?></option>
                <option value="not_in_list"><?php /*_e('Not In List', 'woo-discount-rules'); */ ?></option>
            </select>
        </div>
        <div class="wdr-product-selector">
            <select multiple="" class="cat_search" name="filters[{i}][value][]"
                    data-placeholder="Search a product…"
                    data-action="woocommerce_json_search_products_and_variations" tabindex="-1"
                    style="width: 100%; max-width: 400px;  min-width: 180px;" disabled>
            </select>
        </div>
    </div>-->
</div>
